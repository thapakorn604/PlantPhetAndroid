package com.example.msiraider.newproject.FAQ;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.msiraider.newproject.R;

public class UserManualActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_manual);
    }
}
