package com.example.msiraider.newproject.Map;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.msiraider.newproject.R;

public class MapMenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_menu);


    }
}