package com.example.ploychanok.subscriber.FAQ;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.ploychanok.subscriber.R;

public class aboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_us);
    }
}
